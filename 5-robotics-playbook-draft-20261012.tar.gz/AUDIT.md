# Robotics Playbook draft accuracy checkpoint

12 October 2026. Separate branch only. Main and live deployment unchanged.

Chapter0 orientation; chapters1-3 repaired; chapters4-11 added in the original UI. One complete displayed sketch per practical chapter, each with a matching labelled connection diagram and a downloadable .ino generated from the displayed code. Optional exercise descriptions are not complete sketches and require a wiring/pin review.

## Verified
- TypeScript and Vite production build pass.
- Exact downloadable sketches compile for Uno AVR core1.8.8 / Servo1.3.0, except chapter3, compiled for NodeMCU ESP8266 core3.1.2 / Blynk1.4.0.
- Views0-11 rendered at320,390,1280px without document-width overflow.

## Remaining
- No physical hardware or real phone/app verification.
- Students' Bluetooth board, radio module and app are not yet identified. Chapter3 is ESP8266/Blynk WiFi, not Bluetooth.
- Motor driver regulators, power ratings, clone-module pinouts and servo calibration require exact kit checks before classroom use.
- Current car timeout is conservative and stops when a stationary joystick stops sending updates. Do not claim continuous driving or safety certification.
- Diagrams are labelled terminal connection diagrams, not photoreal breadboard layouts.

Run npm ci, npx tsx scripts/export-sketches.ts, npm run lint and npm run build. Download folders are public/sketches/chapterN/chapterN.ino.
